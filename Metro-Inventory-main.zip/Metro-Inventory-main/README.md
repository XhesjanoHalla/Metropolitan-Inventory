# MetroInventory
To keep track of all the stocks of the school throughout the whole supply chain that the university has can be rather challenging and tiring if done by hand. Noting everything in a piece of paper can also bring up many mistakes that can lead to many situations that the university does not want to be in. In order to keep track of every good and possession that the university has it is very useful to have a system that sorts everything in classes, offices of the professors and in the storage rooms.



The Inventory System web application is the best solution to sort all these problems. The information will be stored in a protected server which would be very flexible in the way of modifying it.



